<?php

return [
    'configurable_routes' => [

    ],

    ROUTE_TYPE_AVOIDABLE_MAINTENANCE => [

    ],
    ROUTE_TYPE_AVOIDABLE_UNVERIFIED => [

    ],
    ROUTE_TYPE_AVOIDABLE_INACTIVE => [

    ],
    ROUTE_TYPE_FINANCIAL => [

    ],

    ROUTE_TYPE_GLOBAL => [

    ],
];
