<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redis;

class TestController extends Controller
{
    public function test()
    {

    }

    public function testPost()
    {

    }
}
