## Trademen -- The Ultimate Exchange Solutions

#### Admin Features 
* Role Management 
* Menu Manager 
* Application Settings 
* Ticket Management 
* User Management
* Wallet Management  
* Wallet Pair Management 
* KYC Management 
* Withdrawal Management 
* Dashboard 


#### User Features 
* Profile Management 
* Preference Setting 
* KYC Verification 
* Google 2 FA 
* My Wallet 
* Deposit
* Deposit History 
* Withdrawal 
* Withdrawal History 
* Dashboard 
* My Orders 
* Market Buy/Sell
* Limit  Buy/Sell
* Stop Limit Buy/Sell 
* Transaction History 
* Activity Log 
